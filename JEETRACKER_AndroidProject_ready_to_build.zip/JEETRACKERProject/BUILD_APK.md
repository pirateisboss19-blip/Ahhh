# Build JEETRACKER APK

This project can be built as a debug APK with Android SDK/Gradle installed:

```bash
gradle assembleDebug
```

The APK will be created at `app/build/outputs/apk/debug/app-debug.apk`.

## Build without installing Android Studio locally

1. Create a GitHub repository and upload the contents of this folder.
2. Open the repository's **Actions** tab.
3. Run **Build JEETRACKER APK** (or push to `main`/`master`).
4. Open the completed workflow run and download the `JEETRACKER-debug-apk` artifact.

This produces a debug-signed APK for testing; it is not a Play Store release build.
